from setuptools import setup


#paquete distribuible en python y como se crea

setup(

    name="paquetecalculos",
    version="1.0.0",
    description="Paquete de redondeo y potencias",
    author="Arthas_dk",
    author_email="kevin.andresfontt@gmail.com",
    url="www.kevinfonttlizama.github.io",
    packages=["calculos","calculos.redondeo_potencias"]
    

)