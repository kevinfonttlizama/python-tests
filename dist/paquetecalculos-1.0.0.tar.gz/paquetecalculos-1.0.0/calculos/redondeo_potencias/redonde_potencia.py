def potencia(base, exponente):
    print("el resultado es de: ", base ** exponente)

def redondear(numero):
    print("el resultado es de: ", round(numero))
