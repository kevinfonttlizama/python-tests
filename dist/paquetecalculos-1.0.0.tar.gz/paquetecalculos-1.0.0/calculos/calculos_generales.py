

def sumar(a,b):
    print("el resultado es de: ", a + b)

def restar(a,b):
    print("el resultado es de: ", a - b)

def multiplicar(a,b):
    print("el resultado es de: ", a * b)

def dividir(dividendo,divisor):
    print("el resultado es de: ", dividendo/divisor)

def potencia(base, exponente):
    print("el resultado es de: ", base ** exponente)

def redondear(numero):
    print("el resultado es de: ", round(numero))

    